GPS-GPRS-GSM-Shield-V3.0
========================

GPS/GPRS/GSM Shield V3.0 using SIM908 chipset. This library aims to provide usability for this chips functionality inside your sketch

## why
this library aims to bring the following functionality
* send message to your phone when you get a GPS fix
* easily add to your code and initialize the shield
* switch easily from GPS to GSM


## howto
